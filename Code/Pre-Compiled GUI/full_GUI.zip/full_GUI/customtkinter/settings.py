
class Settings:
    cursor_manipulation_enabled = True
    deactivate_macos_window_header_manipulation = False
    deactivate_windows_window_header_manipulation = False
    use_dropdown_fallback = True
